from .manifold import (
    Stereographic,
    StereographicExact,
    PoincareBall,
    PoincareBallExact,
    SphereProjection,
    SphereProjectionExact,
)

from . import math
